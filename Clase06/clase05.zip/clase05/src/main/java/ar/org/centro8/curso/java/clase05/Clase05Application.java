package ar.org.centro8.curso.java.clase05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase05Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase05Application.class, args);
	}

}
